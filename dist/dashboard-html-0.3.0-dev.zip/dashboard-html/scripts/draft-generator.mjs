import { acceptGenerationBundle, acceptPlan, createGenerationRun, prepareGenerationPreview, startPlanning } from "./generation-pipeline.mjs";
import { applyCommandBatch, ContractError, migrateWorkspace } from "./workspace-core.mjs";

const domainProfiles = [
  {
    match: /销售|商机|渠道|收入|客户/,
    title: "销售经营看板",
    subtitle: "收入、商机转化、渠道趋势与重点客户风险",
    metrics: [
      ["priority-customers", "重点客户", "128 家", "较上期 +12.4%"],
      ["opportunity-value", "机会金额", "2,460 万", "较上期 +8.2%"],
      ["conversion-rate", "转化率", "32.8%", "较上期 +3.6%"]
    ],
    trendTitle: "机会金额趋势",
    rankingTitle: "来源表现 Top 5",
    rankingItems: ["核心渠道", "自然流量", "合作伙伴", "内容触达", "客户推荐"],
    healthTitle: "重点客户健康度",
    riskTitle: "风险事项"
  },
  {
    match: /运营|增长|流量|活跃|留存/,
    title: "产品运营看板",
    subtitle: "活跃、转化、留存趋势与异常事项",
    metrics: [
      ["priority-customers", "月活用户", "86,420", "较上期 +9.6%"],
      ["opportunity-value", "新增用户", "12,680", "较上期 +14.2%"],
      ["conversion-rate", "核心转化率", "18.6%", "较上期 +1.8%"]
    ],
    trendTitle: "活跃用户趋势",
    rankingTitle: "渠道贡献 Top 5",
    rankingItems: ["自然访问", "内容活动", "合作渠道", "用户推荐", "付费投放"],
    healthTitle: "核心功能健康度",
    riskTitle: "运营异常"
  },
  {
    match: /项目|交付|研发|迭代|进度/,
    title: "项目交付看板",
    subtitle: "交付进度、质量、资源与风险概览",
    metrics: [
      ["priority-customers", "进行中项目", "18 个", "本周新增 2 个"],
      ["opportunity-value", "按期交付率", "91.3%", "较上期 +2.1%"],
      ["conversion-rate", "缺陷关闭率", "87.6%", "较上期 +4.4%"]
    ],
    trendTitle: "里程碑完成趋势",
    rankingTitle: "项目进度 Top 5",
    rankingItems: ["核心平台升级", "移动端迭代", "数据治理", "客户门户", "质量专项"],
    healthTitle: "项目健康度",
    riskTitle: "交付风险"
  }
];

const explicitChartTypeRules = [
  ["pie", /环形图|饼图|donut|pie\s*chart/i],
  ["area", /面积图|area\s*chart/i],
  ["bar", /柱状图|柱形图|条形图|bar\s*chart/i],
  ["line", /折线图|曲线图|line\s*chart/i]
];

const semanticChartTypeRules = [
  ["pie", /占比|构成|份额/],
  ["bar", /排行|排名|分类对比|横向对比|分布/],
  ["area", /累计趋势|累计变化|规模趋势|总量变化/],
  ["line", /趋势|走势|时间序列|变化/]
];

export function inferChartType(prompt) {
  for (const [type, pattern] of explicitChartTypeRules) if (pattern.test(prompt)) return type;
  for (const [type, pattern] of semanticChartTypeRules) if (pattern.test(prompt)) return type;
  return "line";
}

function requestedRefinementChartType(prompt) {
  for (const [type, pattern] of explicitChartTypeRules) if (pattern.test(prompt)) return type;
  if (!/(?:改成|换成|使用|用|调整为|展示为|显示为)/.test(prompt)) return null;
  for (const [type, pattern] of semanticChartTypeRules) if (pattern.test(prompt)) return type;
  return null;
}

function requestedCopy(prompt, field) {
  const labels = field === "title" ? "(?:卡片)?标题" : field === "subtitle" ? "副标题" : "(?:摘要|正文|内容)";
  const match = prompt.match(new RegExp(`${labels}(?:改为|换成|设为|修改为|写成)[“‘\\"']?([^。；，\\n”’\\"']{1,160})`));
  return match?.[1]?.trim() || null;
}

function locateComponent(workspace, componentId) {
  for (const [sectionIndex, section] of workspace.document?.sections?.entries() ?? []) {
    const componentIndex = section.components.findIndex(({ id }) => id === componentId);
    if (componentIndex >= 0) return { section, sectionIndex, component: section.components[componentIndex], componentIndex };
  }
  return null;
}

function locateLayoutItem(workspace, sectionId, componentId) {
  const sectionIndex = workspace.layout.sections.findIndex(({ id }) => id === sectionId);
  if (sectionIndex < 0) return null;
  const section = workspace.layout.sections[sectionIndex];
  const itemIndex = section.items.findIndex(({ id }) => id === componentId);
  return itemIndex < 0 ? null : { section, sectionIndex, item: section.items[itemIndex], itemIndex };
}

function requestedStructureAction(prompt) {
  if (/(?:删除|移除)(?:当前|这张|该|这个)?(?:卡片|模块|图表|指标卡)|(?:当前|这张|该|这个)(?:卡片|模块|图表|指标卡)(?:删除|移除)/.test(prompt)) return "delete";
  if (/(?:新增|添加|再加|插入).{0,8}(?:同类|同样|一样)(?:卡片|模块)?/.test(prompt)) return "add-similar";
  if (/(?:复制|拷贝)(?:当前|这张|该|这个)?(?:卡片|模块|图表|指标卡)?|创建.{0,4}副本/.test(prompt)) return "duplicate";
  return null;
}

function requestedLayoutSpan(prompt) {
  if (/整行|全宽|撑满|12\s*列/.test(prompt)) return 12;
  if (/半宽|一半|6\s*列/.test(prompt)) return 6;
  if (/三分之二|8\s*列/.test(prompt)) return 8;
  if (/三分之一|4\s*列/.test(prompt)) return 4;
  if (/四分之一|3\s*列/.test(prompt)) return 3;
  return null;
}

function requestedMoveDirection(prompt) {
  if (/前移|向前|往前|左移|上移/.test(prompt)) return -1;
  if (/后移|向后|往后|右移|下移/.test(prompt)) return 1;
  return 0;
}

function uniqueComponentId(workspace, targetId, suffix) {
  const ids = new Set(workspace.document.sections.flatMap(({ components }) => components.map(({ id }) => id)));
  const stem = `${targetId}-${suffix}`.slice(0, 92).replace(/-+$/g, "");
  let candidate = stem;
  let index = 2;
  while (ids.has(candidate)) candidate = `${stem}-${index++}`;
  return candidate;
}

function duplicateComponentOperations(workspace, target, layoutTarget, action, requestedTitle) {
  if (target.component.type === "summary") {
    throw new ContractError("Summary duplication is not supported", [{ path: "/request/prompt", code: "unsupported", message: "Select a card inside a content section before adding or duplicating" }]);
  }
  if (target.section.components.length >= 24) {
    throw new ContractError("Section component limit reached", [{ path: `/document/sections/${target.sectionIndex}/components`, code: "limit", message: "A section can contain at most 24 components" }]);
  }
  const suffix = action === "add-similar" ? "new" : "copy";
  const componentId = uniqueComponentId(workspace, target.component.id, suffix);
  const component = structuredClone(target.component);
  component.id = componentId;
  component.title = requestedTitle || `${target.component.title}${action === "add-similar" ? " 2" : " 副本"}`;
  const operations = [
    { op: "insert", path: `/document/sections/${target.sectionIndex}/components/${target.componentIndex + 1}`, value: component, reason: action === "add-similar" ? "新增同类卡片" : "复制卡片" },
    { op: "insert", path: `/layout/sections/${layoutTarget.sectionIndex}/items/${layoutTarget.itemIndex + 1}`, value: { id: componentId, span: layoutTarget.item.span }, reason: "为新卡片建立布局项" }
  ];
  const sourceOverride = workspace.theme.cardOverrides?.[target.component.id];
  if (sourceOverride) operations.push({ op: "set", path: `/theme/cardOverrides/${componentId}`, value: structuredClone(sourceOverride), reason: "复制单卡样式覆盖" });
  const canvasOrder = workspace.layout.canvasOrder;
  const canvasIndex = canvasOrder?.indexOf(target.component.id) ?? -1;
  if (canvasIndex >= 0) {
    const nextOrder = [...canvasOrder];
    nextOrder.splice(canvasIndex + 1, 0, componentId);
    operations.push({ op: "replace", path: "/layout/canvasOrder", value: nextOrder, reason: "将新卡片放在当前卡片之后" });
  }
  for (const [controlIndex, control] of (workspace.document.controls ?? []).entries()) {
    if (control.type !== "filter-bar" || !control.props.targets.includes(target.component.id) || control.props.targets.includes(componentId)) continue;
    operations.push({
      op: "replace",
      path: `/document/controls/${controlIndex}/props/targets`,
      value: [...control.props.targets, componentId],
      reason: "新卡片继承当前筛选范围"
    });
  }
  return { component, operations };
}

function deleteComponentOperations(workspace, target, layoutTarget) {
  if (target.section.components.length <= 1) {
    throw new ContractError("Cannot delete the last component in a section", [{ path: `/document/sections/${target.sectionIndex}/components`, code: "minimum", message: "Move or add another card before deleting the section's last component" }]);
  }
  const operations = [];
  const controls = structuredClone(workspace.document.controls ?? []);
  const removedFilterIds = [];
  let controlsChanged = false;
  for (let index = controls.length - 1; index >= 0; index -= 1) {
    const control = controls[index];
    if (control.type !== "filter-bar" || !control.props.targets.includes(target.component.id)) continue;
    control.props.targets = control.props.targets.filter((id) => id !== target.component.id);
    controlsChanged = true;
    if (!control.props.targets.length) {
      removedFilterIds.push(...control.props.controls.map(({ id }) => id));
      controls.splice(index, 1);
    }
  }
  if (controlsChanged) operations.push({ op: "replace", path: "/document/controls", value: controls, reason: "清理失效筛选目标" });
  for (const filterId of removedFilterIds) {
    if (Object.hasOwn(workspace.interactions?.filters ?? {}, filterId)) operations.push({ op: "unset", path: `/interactions/filters/${filterId}`, reason: "清理失效筛选状态" });
  }
  if (Object.hasOwn(workspace.theme.cardOverrides ?? {}, target.component.id)) {
    operations.push({ op: "unset", path: `/theme/cardOverrides/${target.component.id}`, reason: "清理单卡样式覆盖" });
  }
  if (Object.hasOwn(workspace.resources?.charts ?? {}, target.component.id)) {
    operations.push({ op: "unset", path: `/resources/charts/${target.component.id}`, reason: "清理卡片图表资源" });
  }
  const canvasOrder = workspace.layout.canvasOrder;
  if (canvasOrder?.includes(target.component.id)) {
    operations.push({ op: "replace", path: "/layout/canvasOrder", value: canvasOrder.filter((id) => id !== target.component.id), reason: "从画布顺序移除卡片" });
  }
  operations.push(
    { op: "remove", path: `/layout/sections/${layoutTarget.sectionIndex}/items/${layoutTarget.itemIndex}`, reason: "移除卡片布局项" },
    { op: "remove", path: `/document/sections/${target.sectionIndex}/components/${target.componentIndex}`, reason: "删除卡片" }
  );
  return operations;
}

function moveComponentOperations(workspace, target, layoutTarget, direction) {
  const operations = [];
  const componentDestination = target.componentIndex + direction;
  if (componentDestination >= 0 && componentDestination < target.section.components.length) {
    operations.push({
      op: "move",
      from: `/document/sections/${target.sectionIndex}/components/${target.componentIndex}`,
      path: `/document/sections/${target.sectionIndex}/components/${componentDestination}`,
      reason: direction < 0 ? "卡片前移" : "卡片后移"
    });
  }
  const itemDestination = layoutTarget.itemIndex + direction;
  if (itemDestination >= 0 && itemDestination < layoutTarget.section.items.length) {
    operations.push({
      op: "move",
      from: `/layout/sections/${layoutTarget.sectionIndex}/items/${layoutTarget.itemIndex}`,
      path: `/layout/sections/${layoutTarget.sectionIndex}/items/${itemDestination}`,
      reason: direction < 0 ? "布局项前移" : "布局项后移"
    });
  }
  const canvasOrder = workspace.layout.canvasOrder;
  const canvasIndex = canvasOrder?.indexOf(target.component.id) ?? -1;
  const canvasDestination = canvasIndex + direction;
  if (canvasIndex >= 0 && canvasDestination >= 0 && canvasDestination < canvasOrder.length) {
    const nextOrder = [...canvasOrder];
    const [componentId] = nextOrder.splice(canvasIndex, 1);
    nextOrder.splice(canvasDestination, 0, componentId);
    operations.push({ op: "replace", path: "/layout/canvasOrder", value: nextOrder, reason: direction < 0 ? "画布节点前移" : "画布节点后移" });
  }
  if (!operations.length) {
    throw new ContractError("Component cannot move farther", [{ path: "/request/prompt", code: "boundary", message: direction < 0 ? "The selected card is already first" : "The selected card is already last" }]);
  }
  return operations;
}

function selectProfile(prompt) {
  return domainProfiles.find(({ match }) => match.test(prompt)) || domainProfiles[0];
}

function inferPageType(prompt, requested) {
  if (["dashboard", "report"].includes(requested)) return requested;
  return /报告|复盘|总结|分析/.test(prompt) && !/看板|监控/.test(prompt) ? "report" : "dashboard";
}

function buildPageControls(prompt, sections) {
  const controls = [];
  const targets = sections.flatMap((section) => [section.id, ...section.components.map(({ id }) => id)]);
  const filterDefinitions = [];
  if (/年份|年度|按年/.test(prompt)) filterDefinitions.push({ id: "year", label: "年份", field: "year", options: [{ value: "", label: "全部年份" }, { value: "2026", label: "2026 年" }, { value: "2025", label: "2025 年" }], defaultValue: "" });
  if (/月份|月度|按月/.test(prompt)) filterDefinitions.push({ id: "month", label: "月份", field: "month", options: [{ value: "", label: "全部月份" }, { value: "current", label: "本月" }, { value: "previous", label: "上月" }], defaultValue: "" });
  if (/战区|区域|地区/.test(prompt)) filterDefinitions.push({ id: "region", label: "区域", field: "region", options: [{ value: "", label: "全部区域" }, { value: "east", label: "华东" }, { value: "south", label: "华南" }, { value: "north", label: "华北" }], defaultValue: "" });
  if (/行业/.test(prompt)) filterDefinitions.push({ id: "industry", label: "行业", field: "industry", options: [{ value: "", label: "全部行业" }, { value: "technology", label: "科技" }, { value: "retail", label: "零售" }, { value: "manufacturing", label: "制造" }], defaultValue: "" });
  if (/筛选|过滤/.test(prompt) && !filterDefinitions.length) filterDefinitions.push({ id: "period", label: "周期", field: "period", options: [{ value: "", label: "全部周期" }, { value: "current", label: "本期" }, { value: "previous", label: "上期" }], defaultValue: "" });
  if (filterDefinitions.length) controls.push({ id: "dashboard-filters", type: "filter-bar", props: { controls: filterDefinitions.map((filter) => ({ ...filter, control: "select" })), targets, surface: "card" } });
  if (/视图|tab|切换/i.test(prompt)) {
    const splitIndex = Math.max(1, Math.ceil(sections.length / 2));
    controls.push({
      id: "dashboard-views",
      type: "view-tabs",
      props: {
        items: [
          { id: "overview", label: "概览", sectionIds: sections.slice(0, splitIndex).map(({ id }) => id) },
          { id: "details", label: "明细", sectionIds: sections.slice(splitIndex).map(({ id }) => id) }
        ],
        defaultValue: "overview"
      }
    });
  }
  return controls;
}

function buildSampleRecords(profile) {
  const regions = ["east", "south", "north"];
  const industries = ["technology", "retail", "manufacturing"];
  const owners = ["王琳", "陈昊", "李敏"];
  const statuses = ["稳健", "关注", "风险"];
  const sources = profile.rankingItems;
  const risks = ["进度风险", "跟进停滞", "数据待确认"];
  return Array.from({ length: 12 }, (_, index) => ({
    year: index < 8 ? "2026" : "2025",
    month: index % 2 === 0 ? "current" : "previous",
    period: index < 6 ? "current" : "previous",
    region: regions[index % regions.length],
    industry: industries[index % industries.length],
    periodLabel: `第 ${index % 6 + 1} 周`,
    priorityCustomers: 8 + index * 2,
    opportunityValue: 120 + index * 35,
    conversionRate: 22 + index * 1.7,
    objectName: `重点对象 ${String.fromCharCode(65 + index)}`,
    ownerName: owners[index % owners.length],
    healthScore: Math.max(58, 94 - index * 3),
    statusName: statuses[index % statuses.length],
    sourceName: sources[index % sources.length],
    riskName: risks[index % risks.length],
    riskCount: 1 + index % 4
  }));
}

function buildDocument(profile, request, pageType) {
  const requestedTitle = request.prompt.match(/(?:叫做|标题为|名称为)[“‘"']?([^。，“”‘’"']{2,30})/)?.[1]?.trim();
  const title = requestedTitle || `${profile.title}${pageType === "report" ? "报告" : ""}`;
  const sampleDataLabel = request.dataInputs.some(({ kind }) => kind !== "sample") ? undefined : "示例数据";
  const dataRef = request.dataInputs[0]?.id || "primary-data";
  const bindData = request.dataInputs.every(({ kind }) => kind === "sample");
  const chartType = inferChartType(request.prompt);
  const asksForTimeSeries = /最近|趋势|走势|时间|周|月|季度|年度/.test(request.prompt);
  const usesCompositionCategories = chartType === "pie"
    || (!asksForTimeSeries && /渠道|来源|分类|排行|排名|对比|分布/.test(request.prompt));
  const chartCategoryField = usesCompositionCategories ? "sourceName" : "periodLabel";
  const chartTitle = usesCompositionCategories ? profile.rankingTitle.replace(/\s*Top\s*5/i, "构成") : profile.trendTitle;
  const chartSubtitle = usesCompositionCategories ? "本周期贡献占比" : "最近 7 个周期";
  const metricBindings = [
    { kind: "aggregate", operation: "sum", field: "priorityCustomers", format: { suffix: " 家" } },
    { kind: "aggregate", operation: "sum", field: "opportunityValue", format: { suffix: " 万" } },
    { kind: "aggregate", operation: "average", field: "conversionRate", format: { suffix: "%", maximumFractionDigits: 1 } }
  ];
  const sections = [
      {
        id: "summary",
        title: "经营摘要",
        subtitle: sampleDataLabel || "核心结论",
        components: [{ id: "summary-card", type: "summary", title: "经营摘要", subtitle: sampleDataLabel || "核心结论", props: { body: `${title}当前整体表现稳定，核心指标保持增长，仍需关注风险事项并持续验证数据口径。`, score: "91.3%", scoreLabel: "综合目标完成率" } }]
      },
      {
        id: "metrics",
        title: "核心指标",
        subtitle: sampleDataLabel || "当前周期",
        components: profile.metrics.map(([id, titleText, value, trend], index) => ({ id, type: "kpi", title: titleText, subtitle: trend, dataRef, ...(bindData ? { binding: metricBindings[index] } : {}), props: { value, trend } }))
      },
      {
        id: "trends",
        title: "趋势与来源",
        subtitle: sampleDataLabel || "最近周期",
        components: [
          { id: "opportunity-trend", type: "chart", title: chartTitle, subtitle: chartSubtitle, dataRef, ...(bindData ? { binding: { kind: "series", categoryField: chartCategoryField, valueField: "opportunityValue", operation: "sum" } } : {}), props: { chartType, labels: [], values: [] } },
          { id: "source-ranking", type: "list", title: profile.rankingTitle, subtitle: "本周期贡献占比", dataRef, ...(bindData ? { binding: { kind: "ranking", labelField: "sourceName", valueField: "opportunityValue", operation: "sum", limit: 5 } } : {}), props: { items: profile.rankingItems.map((label, index) => ({ label, value: [92, 78, 66, 57, 44][index] })) } }
        ]
      },
      {
        id: "health",
        title: "健康与风险",
        subtitle: sampleDataLabel || "最近 30 天",
        components: [
          { id: "customer-health", type: "table", title: profile.healthTitle, subtitle: "最近 30 天综合表现", dataRef, ...(bindData ? { binding: { kind: "rows", columns: [{ field: "objectName", label: "对象" }, { field: "ownerName", label: "负责人" }, { field: "healthScore", label: "健康分" }, { field: "statusName", label: "状态" }], limit: 8 } } : {}), props: { columns: ["对象", "负责人", "健康分", "状态"], rows: [["重点对象 A", "王琳", 92, "稳健"], ["重点对象 B", "陈昊", 84, "关注"], ["重点对象 C", "李敏", 63, "风险"]] } },
          { id: "risk-items", type: "list", title: profile.riskTitle, subtitle: "当前待处理事项", dataRef, ...(bindData ? { binding: { kind: "ranking", labelField: "riskName", valueField: "riskCount", operation: "sum", limit: 3 } } : {}), props: { items: [{ label: "进度风险", value: 6 }, { label: "跟进停滞", value: 4 }, { label: "数据待确认", value: 3 }] } }
        ]
      }
    ];
  const controls = buildPageControls(request.prompt, sections);
  return { title, subtitle: profile.subtitle, ...(sampleDataLabel ? { sampleDataLabel } : {}), ...(controls.length ? { controls } : {}), sections };
}

function buildLayout() {
  return {
    canvasOrder: ["summary-card", "metrics", "opportunity-trend", "source-ranking", "customer-health", "risk-items"],
    sections: [
      { id: "summary", grouped: false, span: 12, layout: null, items: [{ id: "summary-card", span: 12 }] },
      { id: "metrics", grouped: true, span: 12, layout: "responsive", items: [{ id: "priority-customers", span: 4 }, { id: "opportunity-value", span: 4 }, { id: "conversion-rate", span: 4 }] },
      { id: "trends", grouped: false, span: 12, layout: "responsive", items: [{ id: "opportunity-trend", span: 8 }, { id: "source-ranking", span: 4 }] },
      { id: "health", grouped: false, span: 12, layout: "responsive", items: [{ id: "customer-health", span: 8 }, { id: "risk-items", span: 4 }] }
    ]
  };
}

export function createDeterministicDraft(input, baseWorkspace, { runId = `run-${input.id}`, now = new Date().toISOString() } = {}) {
  const profile = selectProfile(input.prompt);
  const pageType = inferPageType(input.prompt, input.pageType);
  const baseline = migrateWorkspace(baseWorkspace);
  const request = {
    ...input,
    pageType,
    dataInputs: input.dataInputs?.length ? input.dataInputs : [{ id: "primary-data", kind: "sample", name: "AI 首稿示例数据" }]
  };
  const document = buildDocument(profile, request, pageType);
  const dataRef = request.dataInputs[0]?.id || "primary-data";
  const portableDataset = request.dataInputs.every(({ kind }) => kind === "sample") ? { [dataRef]: { portable: true, records: buildSampleRecords(profile) } } : null;
  const cardOverrides = Object.fromEntries(Object.entries(baseline.theme.cardOverrides ?? {}).map(([cardId, override]) => {
    const next = { ...override };
    delete next.chartType;
    return [cardId, next];
  }).filter(([, override]) => Object.keys(override).length));
  const generatedChart = document.sections.flatMap(({ components }) => components).find(({ type }) => type === "chart");
  if (generatedChart?.props.chartType === "pie" && !cardOverrides[generatedChart.id]?.chartPalette) {
    cardOverrides[generatedChart.id] = { ...(cardOverrides[generatedChart.id] ?? {}), chartPalette: "categorical" };
  }
  const workspace = {
    ...baseline,
    document,
    theme: { ...baseline.theme, cardOverrides, pageType, language: request.language || "zh", paletteVersion: "1.2.0" },
    layout: buildLayout(),
    ...(document.controls?.length ? {
      interactions: {
        filters: Object.fromEntries(document.controls.filter(({ type }) => type === "filter-bar").flatMap(({ props }) => props.controls.map(({ id, defaultValue }) => [id, defaultValue]))),
        ...(document.controls.some(({ type }) => type === "view-tabs") ? { activeView: document.controls.find(({ type }) => type === "view-tabs").props.defaultValue } : {})
      }
    } : {})
  };
  const preservedResources = { ...(baseline.resources ?? {}) };
  delete preservedResources.datasets;
  if (portableDataset) workspace.resources = { ...preservedResources, datasets: portableDataset };
  else if (Object.keys(preservedResources).length) workspace.resources = preservedResources;
  else delete workspace.resources;
  if (!document.controls?.length) delete workspace.interactions;
  const plan = {
    pageType,
    title: document.title,
    goal: request.prompt,
    sections: document.sections.map((section) => ({
      id: section.id,
      title: section.title,
      purpose: section.subtitle || section.title,
      components: section.components.map((component) => ({ id: component.id, type: component.type, purpose: component.title, dataInputId: component.dataRef || null }))
    })),
    assumptions: request.dataInputs.every(({ kind }) => kind === "sample") ? ["当前使用示例数据生成首稿。"] : [],
    warnings: ["正式使用前请确认指标口径和数据来源。"]
  };
  const source = request.dataInputs[0]?.kind === "sample" ? "sample" : "real";
  const componentProvenance = document.sections.flatMap(({ components }) => components.map((component) => [
    component.id,
    {
      source,
      label: source === "sample" ? "示例数据" : "用户提供数据",
      ...(component.dataRef ? { dataInputId: component.dataRef } : {})
    }
  ]));
  const bundle = {
    version: 1,
    request,
    plan,
    workspace,
    commands: { batchId: `batch-${runId}`, source: "agent", reason: "生成自然语言首稿", operations: [{ op: "replace", path: "/", value: workspace }] },
    provenance: {
      mode: source,
      components: Object.fromEntries(componentProvenance)
    }
  };
  let run = createGenerationRun(request, { runId, now });
  run = startPlanning(run, { at: now });
  run = acceptPlan(run, plan, { at: now });
  run = acceptGenerationBundle(run, bundle, { at: now });
  run = prepareGenerationPreview(run, baseline, { at: now });
  return run;
}

export function createDeterministicRefinement(input, baseWorkspace, { runId = `refine-${input.id}`, now = new Date().toISOString() } = {}) {
  const baseline = migrateWorkspace(baseWorkspace);
  if (input.scope?.kind !== "component" || !input.scope.id) {
    throw new ContractError("Local AI refinement requires a component scope", [{ path: "/request/scope", code: "required", message: "Select a structured component before requesting a local refinement" }]);
  }
  const target = locateComponent(baseline, input.scope.id);
  if (!target) throw new ContractError("Refinement target was not found", [{ path: "/request/scope/id", code: "reference", message: "Target component does not exist in the current workspace" }]);

  const operations = [];
  const componentPath = `/document/sections/${target.sectionIndex}/components/${target.componentIndex}`;
  const layoutTarget = locateLayoutItem(baseline, target.section.id, target.component.id);
  if (!layoutTarget) throw new ContractError("Refinement layout target was not found", [{ path: "/layout/sections", code: "reference", message: "Target component does not have a layout item" }]);
  const structureAction = requestedStructureAction(input.prompt);
  const requestedTitle = requestedCopy(input.prompt, "title");
  let addedComponent = null;
  let operationLabel = "修改";

  if (structureAction === "delete") {
    operations.push(...deleteComponentOperations(baseline, target, layoutTarget));
    operationLabel = "删除";
  } else if (["duplicate", "add-similar"].includes(structureAction)) {
    const duplicated = duplicateComponentOperations(baseline, target, layoutTarget, structureAction, requestedTitle);
    operations.push(...duplicated.operations);
    addedComponent = duplicated.component;
    operationLabel = structureAction === "duplicate" ? "复制" : "新增";
  } else {
    const chartType = target.component.type === "chart" ? requestedRefinementChartType(input.prompt) : null;
    if (chartType && target.component.props.chartType !== chartType) {
      operations.push({ op: target.component.props.chartType === undefined ? "set" : "replace", path: `${componentPath}/props/chartType`, value: chartType, reason: "按局部指令替换图表类型" });
      if (chartType === "pie" && !baseline.theme.cardOverrides?.[target.component.id]?.chartPalette) {
        const cardOverrides = structuredClone(baseline.theme.cardOverrides ?? {});
        cardOverrides[target.component.id] = { ...(cardOverrides[target.component.id] ?? {}), chartPalette: "categorical" };
        operations.push({ op: baseline.theme.cardOverrides === undefined ? "set" : "replace", path: "/theme/cardOverrides", value: cardOverrides, reason: "环形图使用分类色板" });
      }
    }

    if (requestedTitle && requestedTitle !== target.component.title) operations.push({ op: "replace", path: `${componentPath}/title`, value: requestedTitle, reason: "改写卡片标题" });
    const removesSubtitle = /(?:去掉|隐藏|删除).{0,6}副标题|副标题.{0,6}(?:去掉|隐藏|删除)/.test(input.prompt);
    const subtitle = removesSubtitle ? "" : requestedCopy(input.prompt, "subtitle");
    if (subtitle !== null && subtitle !== (target.component.subtitle ?? "")) {
      operations.push({ op: target.component.subtitle === undefined ? "set" : "replace", path: `${componentPath}/subtitle`, value: subtitle, reason: removesSubtitle ? "隐藏卡片副标题" : "改写卡片副标题" });
    }
    const body = target.component.type === "summary" ? requestedCopy(input.prompt, "body") : null;
    if (body && body !== target.component.props.body) operations.push({ op: "replace", path: `${componentPath}/props/body`, value: body, reason: "改写摘要正文" });

    const span = requestedLayoutSpan(input.prompt);
    if (span && span !== layoutTarget.item.span) {
      operations.push({ op: "replace", path: `/layout/sections/${layoutTarget.sectionIndex}/items/${layoutTarget.itemIndex}/span`, value: span, reason: "调整卡片宽度" });
      if (layoutTarget.section.grouped && layoutTarget.section.layout !== "custom") {
        operations.push({ op: "replace", path: `/layout/sections/${layoutTarget.sectionIndex}/layout`, value: "custom", reason: "启用组内自由尺寸" });
      }
    }
    const moveDirection = requestedMoveDirection(input.prompt);
    if (moveDirection) operations.push(...moveComponentOperations(baseline, target, layoutTarget, moveDirection));
  }

  if (!operations.length) {
    throw new ContractError("No supported local change was found", [{
      path: "/request/prompt",
      code: "unsupported",
      message: target.component.type === "chart"
        ? "Try changing the chart type, title, subtitle, width, order, or card structure"
        : target.component.type === "summary" ? "Try changing the title, subtitle, summary body, or width" : "Try changing the title, subtitle, width, order, or card structure"
    }]);
  }

  const commands = { batchId: `batch-${runId}`, source: "agent", reason: `${operationLabel}卡片：${target.component.title}`, operations };
  const workspace = applyCommandBatch(baseline, commands);
  const request = {
    ...input,
    pageType: baseline.theme.pageType,
    language: input.language || baseline.theme.language || "zh",
    dataInputs: input.dataInputs ?? []
  };
  let run = createGenerationRun(request, { runId, now });
  const plannedComponents = [
    { id: target.component.id, type: target.component.type, purpose: input.prompt },
    ...(addedComponent ? [{ id: addedComponent.id, type: addedComponent.type, purpose: `${operationLabel}自 ${target.component.id}` }] : [])
  ];
  const plan = {
    pageType: baseline.theme.pageType,
    title: `${operationLabel} ${target.component.title}`,
    goal: input.prompt,
    sections: [{
      id: target.section.id,
      title: target.section.title,
      purpose: `只修改组件 ${target.component.id}`,
      components: plannedComponents
    }],
    assumptions: [],
    warnings: addedComponent ? ["新增卡片沿用原卡片的数据绑定和局部样式，可继续单独修改。"] : []
  };
  const source = baseline.document.sampleDataLabel ? "sample" : "real";
  const sourceLabel = source === "sample" ? baseline.document.sampleDataLabel : "当前工作区数据";
  const bundle = {
    version: 1,
    request: run.request,
    plan,
    workspace,
    commands,
    provenance: {
      mode: source,
      components: Object.fromEntries(plannedComponents.map(({ id }) => [id, { source, label: sourceLabel }]))
    }
  };
  run = startPlanning(run, { at: now });
  run = acceptPlan(run, plan, { at: now });
  run = acceptGenerationBundle(run, bundle, { at: now });
  run = prepareGenerationPreview(run, baseline, { at: now });
  return run;
}
